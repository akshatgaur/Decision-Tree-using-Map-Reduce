
How To run the code:
	1. Execute the TreeNode.py file in the zip from terminal/command prompt
	2. It will output the tree structure
 	3. It will also output the predictions for the given data set


The Accuracy and confusion matrix are attached in the Accuracy.txt file